console.log('App starting');

const rawInput = process.argv[2] ?? '';
//const datasetSecretKey = process.argv[3] ?? '';
//const authPublicKey = process.argv[4] ?? '';
//const dataset = process.argv[5] ?? '';
console.log(process.env.IEXEC_TASK_ID);
console.log(rawInput);

process.send('output data');

process.exit(0);
