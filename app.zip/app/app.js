console.log('App starting')

const datasetSecretKey = process.argv[2] ?? ''
const authPublicKey = process.argv[3] ?? ''
const dataset = process.argv[4] ?? ''
const requestInput = process.argv[5] ?? ''
console.log(datasetSecretKey);
console.log(authPublicKey);
console.log(dataset);
console.log(requestInput);

process.send('output data');

process.exit(0);
