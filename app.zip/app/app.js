console.log('App starting');

const taskId = process.argv[2] ?? '';
const rawInput = process.argv[3] ?? '';
//const datasetSecretKey = process.argv[4] ?? '';
//const authPublicKey = process.argv[5] ?? '';
//const dataset = process.argv[6] ?? '';
console.log(taskId);
console.log(rawInput);

process.send('output data');

process.exit(0);
